document.addEventListener('DOMContentLoaded', () => {
    // Handle Encrypt Form Submission
    document.getElementById('encrypt-form').addEventListener('submit', function(event) {
        event.preventDefault();
    
        var formData = new FormData(this);
        var xhr = new XMLHttpRequest();
        
        xhr.open('POST', '/encrypt', true);
        
        xhr.onload = function() {
            if (xhr.status === 200) {
                try {
                    var response = JSON.parse(xhr.responseText);
                    var downloadUrl = response.download_url;
    
                    // Redirect the browser to download the file
                    window.location.href = downloadUrl;
                } catch (e) {
                    alert('Error parsing response: ' + e.message);
                }
            } else {
                alert('An error occurred during the request: ' + xhr.statusText);
            }
        };
    
        xhr.onerror = function() {
            alert('Request failed. Please check your network connection and try again.');
        };
    
        xhr.send(formData);
    });
    

    // Handle Decrypt Form Submission
    document.getElementById('decrypt-form').addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Show the loader
        document.getElementById('loader').style.display = 'flex';

        const formData = new FormData(this);

        fetch('/decrypt', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            // Hide the loader
            document.getElementById('loader').style.display = 'none';
            
            // Display extracted message
            document.getElementById('extracted-message').textContent = data.message;
        })
        .catch(error => {
            console.error('Error:', error);
            document.getElementById('loader').style.display = 'none';
        });
    });
});

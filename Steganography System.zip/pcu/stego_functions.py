from PIL import Image
import io

# Function to encode a message into an image
def encrypt_image(image_file, message):
    image = Image.open(image_file)
    encoded_image = image.convert('RGB')
    
    # Convert message to binary
    binary_message = ''.join([format(ord(char), '08b') for char in message])
    binary_message += '1111111111111110'  # Stop sequence

    data_index = 0
    pixel_list = list(encoded_image.getdata())

    for i in range(len(pixel_list)):
        if data_index < len(binary_message):
            r, g, b = pixel_list[i]
            # Encode data into the Red channel's least significant bit
            new_r = (r & ~1) | int(binary_message[data_index])
            pixel_list[i] = (new_r, g, b)
            data_index += 1

    encoded_image.putdata(pixel_list)

    output = io.BytesIO()
    encoded_image.save(output, format='PNG')
    return output.getvalue()

# Function to decode a message from an image
def decrypt_image(image_file):
    image = Image.open(image_file)
    pixel_list = list(image.getdata())

    binary_message = ''
    for pixel in pixel_list:
        r, g, b = pixel
        binary_message += str(r & 1)

    # Group binary message into 8-bit chunks and convert to characters
    byte_message = [binary_message[i:i+8] for i in range(0, len(binary_message), 8)]
    message = ''.join([chr(int(byte, 2)) for byte in byte_message])

    # Split the message at the stop sequence
    message = message.split(chr(255), 1)[0]
    
    return message

from flask import Flask, request, jsonify, render_template, redirect, url_for, session, send_file
import stego_functions
import io
from werkzeug.security import generate_password_hash, check_password_hash
from flask_pymongo import PyMongo

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Replace with a strong secret key

# Initialize MongoDB
app.config["MONGO_URI"] = "mongodb://localhost:27017/stego_db"
mongo = PyMongo(app)

# Serve the home page
@app.route('/')
def home():
    return render_template('index.html')

# Serve login page
@app.route('/login')
def login_page():
    return render_template('login.html')

# Serve signup page
@app.route('/signup')
def signup_page():
    return render_template('signup.html')

# Serve forgot password page
@app.route('/forgot-password')
def forgot_password_page():
    return render_template('forgot_password.html')

# Serve dashboard page
@app.route('/dashboard')
def dashboard():
    if 'username' in session:
        extracted_message = request.args.get('extracted_message', None)
        return render_template('dashboard.html',extracted_message=extracted_message)
    return redirect(url_for('login_page'))

# Authentication routes
@app.route('/signup', methods=['POST'])
def signup():
    username = request.form.get('username')
    password = request.form.get('password')
    extracted_message = create_user(username, password)
    if extracted_message == "User created successfully!! Please login":
        return render_template('login.html',extracted_message=extracted_message)
    else:
        return render_template('signup.html',extracted_message=extracted_message)
    
    
    

@app.route('/login', methods=['POST'])
def login():
    username = request.form.get('username')
    password = request.form.get('password')
    if verify_user(username, password):
        session['username'] = username
        return redirect(url_for('dashboard'))
    return jsonify({"message": "Invalid credentials"}), 401

@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('login_page'))

@app.route('/forgot-password', methods=['POST'])
def forgot_password():
    username = request.form.get('username')
    new_password = request.form.get('new_password')
    extracted_message = reset_password(username, new_password)
    return render_template('forgot_password.html',extracted_message=extracted_message)

# Image encryption route
@app.route('/encrypt', methods=['POST'])
def encrypt_image():
    image_file = request.files['image']
    message = request.form['message']
    
    # Encrypt image
    encoded_image = stego_functions.encrypt_image(image_file, message)
    
    # Save the encoded image
    file_path = 'encoded_image.png'
    with open(file_path, 'wb') as f:
        f.write(encoded_image)
    
    # Return the encoded image for download
    return send_file(file_path, as_attachment=True, download_name='encoded_image.png')

# Image decryption route
@app.route('/decrypt', methods=['POST'])
def decrypt_image():
    encoded_image = request.files['encoded_image'].read()
    extracted_message = stego_functions.decrypt_image(io.BytesIO(encoded_image))
    
    return redirect(url_for('dashboard', extracted_message=extracted_message))

# MongoDB operations
def create_user(username, password):
    if mongo.db.users.find_one({'username': username}):
        return "User already exists"
    hashed_password = generate_password_hash(password)
    mongo.db.users.insert_one({'username': username, 'password': hashed_password})
    return "User created successfully!! Please login"

def verify_user(username, password):
    user = mongo.db.users.find_one({'username': username})
    if user and check_password_hash(user['password'], password):
        return True
    return False

def reset_password(username, new_password):
    hashed_password = generate_password_hash(new_password)
    mongo.db.users.update_one({'username': username}, {'$set': {'password': hashed_password}})
    return "Password reset successfully"

if __name__ == '__main__':
    app.run(debug=True)

